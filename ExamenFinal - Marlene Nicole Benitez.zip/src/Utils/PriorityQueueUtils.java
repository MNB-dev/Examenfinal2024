package Utils;

import implementation.normal.PriorityQueueOriginal;
import implementation.normal.Queue;
import model.IPriorityQueue;
import model.IQueue;

public class PriorityQueueUtils {

    /**
     * Imprime la cola ordenarada por prioridad.
     * @param queue
     */
    public static void print(IPriorityQueue q) {
        IPriorityQueue pq = copyPriorityQueue(q);
        while (!pq.isEmpty()) {
            System.out.println("Valor: " + pq.getFirst() + " Prioridad: " + pq.getPriority());
            pq.remove();
        }
    }

    /**
     * Devuelve la cola.
     * @param queue
     */
    public static IQueue copy(IPriorityQueue queue) {
        IQueue copy = new Queue();
        IPriorityQueue aux = new PriorityQueueOriginal();

        while (!queue.isEmpty()) {
            aux.add(queue.getFirst(), queue.getPriority());
            copy.add(queue.getFirst());
            queue.remove();
        }
        while (!aux.isEmpty()) {
            queue.add(aux.getFirst(), aux.getPriority());
            aux.remove();
        }
        return copy;
    }

    /**
     * Devuelve la cola con prioridad.
     * @param queue
     */
    public static IPriorityQueue copyPriorityQueue(IPriorityQueue queue) {
        IPriorityQueue copy = new PriorityQueueOriginal();
        IPriorityQueue aux = new PriorityQueueOriginal();

        while (!queue.isEmpty()) {
            aux.add(queue.getFirst(), queue.getPriority());
            copy.add(queue.getFirst(), queue.getPriority());
            queue.remove();
        }
        while (!aux.isEmpty()) {
            queue.add(aux.getFirst(), aux.getPriority());
            aux.remove();
        }
        return copy;
    }

    /**
     * Permite editar el par (k, v) a otro par (k’, v).
     * @param queue
     */
    public static IPriorityQueue edit(IPriorityQueue queue, int priority, int newPriority) {
        IPriorityQueue copy = copyPriorityQueue(queue);
        IPriorityQueue res = new PriorityQueueOriginal();
        int nextPriority = newPriority + 1;
        int prevPriority = 0;

        while(!copy.isEmpty()) {
            int p = copy.getPriority();
            int val = copy.getFirst();

            copy.remove();

            if(p == priority) {
                res.add(val, newPriority);
                break;
            }

            res.add(val, p);
        }

        while(!copy.isEmpty()) {
            int p = copy.getPriority();
            int val = copy.getFirst();

            copy.remove();

            if (p == newPriority) {
                res.add(val, p);
            }

            if( prevPriority == p) {
                res.add(val, nextPriority - 1);
            }
            else {
                res.add(val, nextPriority);
            }

            prevPriority = p;
            nextPriority++;
        }

        return res;

    }

}
